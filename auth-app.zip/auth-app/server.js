const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const cors = require('cors'); // Allow frontend to communicate with backend
const User = require('./models/User'); // Ensure this path matches your User model

const app = express();
app.use(express.json());
app.use(cors());

// Connect to MongoDB (Replace with your MongoDB URL)
mongoose.connect('mongodb://localhost:27017/authDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// Register Route
app.post('/register', async (req, res) => {
    const { name, email, DOB, password } = req.body;

    try {
        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Save new user to database
        const newUser = new User({ name, email, DOB, password: hashedPassword });
        await newUser.save();

        res.status(201).json({ message: 'User registered successfully!' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

// **LOGIN ROUTE**
app.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
      const user = await User.findOne({ email });
      if (!user) return res.status(400).json({ error: "User not found!" });

      // Compare hashed password
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) return res.status(400).json({ error: "Invalid credentials!" });

      // Generate JWT token
      const token = jwt.sign({ id: user._id }, SECRET_KEY, { expiresIn: "1h" });

      res.json({ message: "Login successful!", token });
  } catch (err) {
      res.status(500).json({ error: "Server error" });
  }
});

// Start Server
app.listen(5000, () => console.log('Server running on port 5000'));

