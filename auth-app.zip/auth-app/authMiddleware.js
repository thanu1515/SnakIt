const jwt = require("jsonwebtoken");

module.exports = function (req, res, next) {
    const token = req.header("Authorization");
    if (!token) return res.status(401).json({ error: "Access denied! No token provided." });

    try {
        const verified = jwt.verify(token, "your_secret_key");
        req.user = verified;
        next(); // Proceed to next middleware
    } catch (err) {
        res.status(400).json({ error: "Invalid token!" });
    }
};

app.get("/dashboard", (req, res) => {
    console.log("Authorization Header:", req.header("Authorization"));
    res.send("Check the server logs.");
});