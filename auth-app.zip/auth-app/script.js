
// Stores the selected restaurant and redirects to the menu page
function openRestaurant(name) {
    localStorage.setItem("selectedRestaurant", name);
    window.location.href = "restaurant.html";
}

// Menu items for each restaurant
const menus = {
   "OTT": [
        { name: "Aloo Paratha", price: 60 },
        { name: "Paneer Paratha", price: 80 },
        { name: "Veg Burrito", price: 80 },
        { name: "Paneer Burrito", price: 90 },
        { name: "Egg Burrito", price: 99 },
        { name: "White Sauce Pasta", price: 119 },
        { name: "Red Sauce Pasta", price: 129 },
        { name: "Brownie with Ice cream", price: 100 },
        { name: "Cold Coffee", price: 80 },
        { name: "Irish Cold Coffee", price: 99 }
    ],
    "Garden Greens": [
        { name: "Sprouts", price: 50 },
        { name: "Egg Burji with Bread", price: 70 },
        { name: "Boiled Egg", price: 10 },
        { name: "Egg Biryani", price: 80 },
        { name: "Veg Biryani", price: 70 },
        { name: "Rajma Chawal", price: 70 },
        { name: "Dal Rice", price: 75 },
        { name: "Noodles", price: 60 },
        { name: "Paneer chila", price: 70 },
        { name: "Chole Bhature", price: 80 }
    ],
    "Tapri": [
        { name: "Masala Tea", price: 40 },
        { name: "Kachori", price: 60 },
        { name: "Samosa", price: 30 },
        { name: "Pav Bhaji", price: 120 },
        { name: "Dal Baati", price: 80 },
        { name: "Vada Pav", price: 80 },
        { name: "Aloo Paratha", price: 100 },
        { name: "Poha", price: 70 },
        { name: "Bread Pakora", price: 90 },
        { name: "Cold Coffee", price: 110 }
    ],
    "Nescafe": [
        { name: "Cappuccino", price: 25},
        { name: "Cold Coffee", price: 45 },
        { name: "Ice Tea", price: 35 },
        { name: "Tea", price: 15 },
        { name: "Vanilla Chino", price: 30 },
        { name: "Maggie", price: 35 },
        { name: "Pizza", price: 90 },
        { name: "Burger", price: 60 },
        { name: "Brownie", price: 50 },
        { name: "Cool Cake", price: 55 }
    ],
    "Frush": [
        { name: "Paneer Fried momos", price: 80 },
        { name: "Chilli Potato", price: 70 },
        { name: "Veg Biriyani", price: 80 },
        { name: "Egg Biriyani", price: 90 },
        { name: "Egg Roll", price: 60 },
        { name: "Veg Roll", price: 50 },
        { name: "Corn Roll", price: 70 },
        { name: "Virgin Mojito", price: 80 },
        { name: "Green Apple Mint Mojito", price: 90 },
        { name: "Black Current", price: 100 }
    ]
};
// Load the restaurant menu dynamically
window.onload = function () {
    let restaurantName = localStorage.getItem("selectedRestaurant");
    
    if (restaurantName && document.getElementById("restaurant-name")) {
        document.getElementById("restaurant-name").innerText = restaurantName;
        
        let menuContainer = document.getElementById("menu-items");
        menuContainer.innerHTML = ""; // Clear previous items

        menus[restaurantName].forEach(item => {
            let div = document.createElement("div");
            div.classList.add("menu-item");
            div.innerHTML = `
                <p>${item.name} - ₹${item.price}</p>
                <input type="number" id="qty-${item.name}" value="1" min="1" />
                <button onclick="addToCart('${item.name}', ${item.price})">Add to Cart</button>
            `;
            menuContainer.appendChild(div);
        });
    }

    if (document.getElementById("cart-items")) {
        loadCart();
    }

    if (document.getElementById("order-history")) {
        loadOrders();
    }
};

// Cart functionality
let cart = JSON.parse(localStorage.getItem("cart")) || [];

function addToCart(name, price) {
    let selectedRestaurant = localStorage.getItem("selectedRestaurant");
    
    // Prevent adding from multiple restaurants
    if (cart.length > 0 && cart[0].restaurant !== selectedRestaurant) {
        alert("You cannot add items from more than one restaurant at a time.");
        return;
    }

    let quantity = document.getElementById(`qty-${name}`).value;
    cart.push({ name, price, quantity: parseInt(quantity), restaurant: selectedRestaurant });
    localStorage.setItem("cart", JSON.stringify(cart));
    alert(`${name} added to cart!`);
}

// Load cart items
function loadCart() {
    let cartContainer = document.getElementById("cart-items");
    cartContainer.innerHTML = "";
    let total = 0;

    cart.forEach((item, index) => {
        let div = document.createElement("div");
        div.innerHTML = `
            <p>${item.name} x${item.quantity} - ₹${item.price * item.quantity}</p>
            <button onclick="removeFromCart(${index})">Remove</button>
        `;
        cartContainer.appendChild(div);
        total += item.price * item.quantity;
    });

    document.getElementById("total-price").innerText = total;
}

// Remove item from cart
function removeFromCart(index) {
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
}

// Place order
function placeOrder() {
    if (cart.length === 0) {
        alert("Cart is empty!");
        return;
    }

    let orders = JSON.parse(localStorage.getItem("orders")) || [];
    orders.push({ items: [...cart], date: new Date().toLocaleString() });

    localStorage.setItem("orders", JSON.stringify(orders));
    localStorage.removeItem("cart");
    alert("Order placed successfully! Redirecting to payment gateway.");
    window.location.href = "https://example.com/payment"; // Redirect to payment gateway
}

// Load order history
function loadOrders() {
    let orderContainer = document.getElementById("order-history");
    let orders = JSON.parse(localStorage.getItem("orders")) || [];

    if (orders.length === 0) {
        orderContainer.innerHTML = "<p>No previous orders.</p>";
        return;
    }

    orders.forEach((order, index) => {
        let div = document.createElement("div");
        div.innerHTML = `
            <h3>Order ${index + 1} - ${order.date}</h3>
            <div>${order.items.map(item => `<p>${item.name} x${item.quantity} - ₹${item.price * item.quantity}</p>`).join("")}</div>
        `;
        orderContainer.appendChild(div);
    });
}

// Clear order history
function clearOrderHistory() {
    localStorage.removeItem("orders");
    loadOrders();
}